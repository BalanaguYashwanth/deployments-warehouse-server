#!/bin/bash
set -e
npm install -g pnpm
pnpm install
