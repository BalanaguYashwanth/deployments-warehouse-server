export class RackResponseDto {
  id: string;
  label: string;
  color: string;
  created_at?: number;
  updated_at?: number;
  count: number;
}
