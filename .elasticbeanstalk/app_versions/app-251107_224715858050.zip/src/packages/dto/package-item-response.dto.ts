export class PackageItemResponseDto {
  id: string;
  package_id: string;
  name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  created_at: number;
  updated_at: number;
}
