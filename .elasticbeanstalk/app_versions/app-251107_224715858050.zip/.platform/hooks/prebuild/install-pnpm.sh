#!/bin/bash
npm install -g pnpm